package Lesson_1.Marathon.Competitor;

public class Cat extends Animal {
    public Cat(String name) {
        super("Кот", name, 200, 20, 0);
    }
}
