package Lesson_1.Marathon.Obstacle;


public class Course {

    public Obstacle[] prepyatstvia;

    public Course(Obstacle... _c){


        this.prepyatstvia = _c;        //System.out.println(_animals[i]);



    }
}
