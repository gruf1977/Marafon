package Lesson_1.Marathon.Obstacle;

import Lesson_1.Marathon.Competitor.Competitor;

public abstract class Obstacle {
    public abstract void doIt(Competitor competitor);
}
